Cada arquivo representa uma instancia no seguinte formato:

- Primeira linha: o primeiro valor � o n�mero de itens, e o segundo o tamanho da mochila
- Linhas subsequentes: uma linha para cada item, onde o primeiro valor da linha � o valor do item e o segundo valor o tamanho do item (ou seja v_i e w_i).
